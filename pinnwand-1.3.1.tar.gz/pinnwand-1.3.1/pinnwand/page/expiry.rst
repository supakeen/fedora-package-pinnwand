Expiry
######

Pastes on this pastebin expire by default. The expiries are set by the pastebin's
administrator.
