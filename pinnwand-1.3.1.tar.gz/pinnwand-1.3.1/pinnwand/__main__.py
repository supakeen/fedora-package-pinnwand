from pinnwand.command import main

main()
