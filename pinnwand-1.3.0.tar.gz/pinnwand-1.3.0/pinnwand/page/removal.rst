Removal
#######

Pastes on this website can be removed by the owner of the paste. There should be a little button in the top bar with a removal link. This removal is instant but in some cases the contents might linger in cache for 2 minutes after hitting the button.

If you can't see the removal link on the show paste page then you might be blocking the cookie pinnwand sets to identify you. If this is the case you can wait for the expiry to expire and the paste will be removed automatically.
